﻿/*Описати інтерфейс IFigure.
 Методи
1. Розрахунок периметра;
2. Розрахунок площі.
Реалізувати інтерфейс IFigure (клас Rectangle, Circle) та доповнити клас такими елементами:

Конструктор, що дозволяє створити екземпляр класу за замовчуванням.
Конструктор, що дозволяє створити екземпляр класу:
1. Із заданим імям;
2. Із заданими довжинами сторін/радіуса.

Метод, що дозволяє:
3. Вивести довжини сторін прямокутника (відповідні змінні для кола) на екран;
Властивості, що дозволяють:
1. Отримати та встановити довжини сторін прямокутника (відповідні змінні для кола) з
обмеженнями – довжини повинні бути більше нуля (доступне для читання і запису), якщо менше-
встановити нуль;
2. Отримати імя обєкта (доступне тільки для читання).
Використовуючи даний клас – в головній функції програми продемонструвати весь
функціонал описавши список обєктів (List<>).
Результати розрахунку периметра та площі, а також довжини сторін вивести на екран і у
файл.
 */

using System;
using System.IO;
using System.Collections.Generic;

namespace Timchenko_A._KB_81__Mod_2._1_
{
    interface IFigure
    {
        double P();
        double S();
    }

    abstract class Figure : IFigure
    {
        public readonly string Name;
        protected Figure(string name)
        {
            this.Name = name;
        }

        public abstract double P();
        public abstract double S();
    }

    class Circle : Figure
    {
        double radius;

        public Circle(string name = "Коло", double radius = 1) : base(name)
        {
            if (radius >= 0)
                this.radius = radius;
            else
                this.radius = 0;
        }

        public override double P()
        {
            return 2 * Math.PI * radius;
        }

        public override double S()
        {
            return Math.PI * radius * radius;
        }
    }

    class Rectangle : Figure
    {
        double a, b;

        public Rectangle(string name = "Прямокутник", double a = 2, double b = 1) : base(name)
        {
            if (a >= 0)
                this.a = a;
            else
                this.a = 0;

            if (b >= 0)
                this.b = b;
            else
                this.b = 0;
        }

        public override double P()
        {
            return 2 * (a + b);
        }

        public override double S()
        {
            return a * b;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<IFigure> list = new List<IFigure>();
            StreamWriter streamWriter = new StreamWriter("Output.txt");

            list.Add(new Circle("Коло", 2));
            list.Add(new Rectangle("Квадрат", 1, 1));

            foreach (IFigure x in list)
            {
                Console.WriteLine($"{(x as Figure).Name} : P = {x.P():F3} S = {x.S():F3}");
                streamWriter.WriteLine($"{(x as Figure).Name} : P = {x.P():F3} S = {x.S():F3}");
            }

            streamWriter.Close();
            Console.ReadKey(true);
        }
    }
}